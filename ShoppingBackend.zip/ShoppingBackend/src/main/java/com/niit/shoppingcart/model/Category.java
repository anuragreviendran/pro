package com.niit.shoppingcart.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table//(name = "Category")
@Component
public class Category {

	private String c_id;
	private String c_name;
	private String c_description;

	private Set<Product> products;

	@OneToMany(mappedBy = "category", fetch = FetchType.EAGER)
	public Set<Product> getProducts() {
		return products;
	}

	public void setProducts(Set<Product> products) {
		this.products = products;
	}

	@Id
	public String getc_id() {
		return c_id;
	}

	public void setc_id(String c_id) {
		this.c_id = c_id;
	}

	public String getc_name() {
		return c_name;
	}

	public void setc_name(String c_name) {
		this.c_name = c_name;
	}

	public String getc_description() {
		return c_description;
	}

	public void setc_description(String c_description) {
		this.c_description = c_description;
	}

}
