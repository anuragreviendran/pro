package com.niit.shoppingcart.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="User")
@Component
public class User implements Serializable
{
	@Id
	private String U_id;
	private String U_name;
	private String U_password;
	private int U_mobile;
	private String U_email;
	private String U_address;
	
	@Column (name="admin",columnDefinition="tinyinit default 0")

	private boolean admin;
	
	public boolean getAdmin() {  //boolean or byte
		return admin;
	}
	public void setAdmin(boolean admin) {
		this.admin = admin;
	}
	public String getU_id() {
		return U_id;
	}
	public void setU_id(String u_id) {
		U_id = u_id;
	}
	public String getU_name() {
		return U_name;
	}
	public void setU_name(String u_name) {
		U_name = u_name;
	}
	public String getU_password() {
		return U_password;
	}
	public void setU_password(String u_password) {
		U_password = u_password;
	}
	public int getU_mobile() {
		return U_mobile;
	}
	public void setU_mobile(int u_mobile) {
		U_mobile = u_mobile;
	}
	public String getU_email() {
		return U_email;
	}
	public void setU_email(String u_email) {
		U_email = u_email;
	}
	public String getU_address() {
		return U_address;
	}
	public void setU_address(String u_address) {
		U_address = u_address;
	}
	
	
	
}
