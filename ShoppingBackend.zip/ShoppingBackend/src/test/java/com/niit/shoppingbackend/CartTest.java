package com.niit.shoppingbackend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.CartDAO;
import com.niit.shoppingcart.model.Cart;

public class CartTest {
	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		context.refresh();

		CartDAO cartDAO = (CartDAO) context.getBean("cartDAO");

		Cart cart = (Cart) context.getBean("cart");

		cart.setId(11);
		cart.setProductName("CNAME120");
		cart.setPrice(1000);
		cart.setQuantity(1);
		cart.setStatus('y');
		//cart.setTotal(1000);
		cart.setUserID("C140");

		cartDAO.saveOrUpdate(cart);
	}
}