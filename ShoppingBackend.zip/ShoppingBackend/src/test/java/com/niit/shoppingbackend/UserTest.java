package com.niit.shoppingbackend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;

public class UserTest {

	public static void main(String[] args) {

	
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		context.refresh();

		UserDAO userDAO = (UserDAO) context.getBean("userDAO");
		
		User user = (User) context.getBean("user");
		
		
	    user.setU_id("U170");
		user.setU_name("UNAME150");
		user.setU_password("123D");
		user.setU_mobile(886759112);
		user.setU_email("aa@mail.com");
		user.setU_address("eeqqqe" );


		userDAO.saveOrUpdate(user);
         
		//System.out.println(" no of users is "   + userDAO.list().size() );
		
		//userDAO.isValidUser("C140", "123D");
	}
}
