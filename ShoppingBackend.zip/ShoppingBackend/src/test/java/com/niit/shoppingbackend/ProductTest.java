package com.niit.shoppingbackend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.model.Product;

public class ProductTest {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		context.refresh();

		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");

		Product product = (Product) context.getBean("product");

		 product.setP_id("C1230");
		 product.setP_name("CNAME120");
		 product.setP_description("CDES120");
		 product.setP_price(1000);
		
		 productDAO.saveOrUpdate(product);
		
		 //System.out.println(" no of product is " + productDAO.list().size() );
	}
}
